/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.utils;

import library.models.*;

public class BookFactory {
    // Factory method to create books
    public static Book createBook(String type, String title, String author) {
        switch (type.toLowerCase()) {
            case "software engineering":
                return new SoftwareEngineeringBook(title, author);
            case "management":
                return new ManagementBook(title, author);
            case "ai":
            case "artificial intelligence":
                return new ArtificialIntelligenceBook(title, author);
            default:
                throw new IllegalArgumentException("Unknown book type: " + type);
        }
    }
}
