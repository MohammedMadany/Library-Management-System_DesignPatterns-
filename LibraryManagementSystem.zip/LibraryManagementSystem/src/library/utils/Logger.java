/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

// Logger class to handle application-wide logging
public class Logger {
    private static Logger instance; // Single instance
    private FileWriter writer; // To write logs to a file

    // Private constructor to restrict instantiation
    private Logger() {
        try {
            writer = new FileWriter("log.txt", true); // Append to the log file
        } catch (IOException e) {
            System.err.println("Failed to initialize Logger: " + e.getMessage());
        }
    }

    // Static method to get the single instance
    public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Method to write log messages
    public void log(String message) {
        try {
            writer.write(LocalDateTime.now() + " - " + message + "\n");
            writer.flush();
        } catch (IOException e) {
            System.err.println("Failed to write log: " + e.getMessage());
        }
    }

    // Method to close the log file
    public void close() {
        try {
            if (writer != null) {
                writer.close();
            }
        } catch (IOException e) {
            System.err.println("Failed to close Logger: " + e.getMessage());
        }
    }
}
