/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.utils;

import library.models.*;

public class UserFactory {
    // Factory method to create users
    public static User createUser(String type, String username) {
        switch (type.toLowerCase()) {
            case "admin":
                return new AdminUser(username);
            
            case "regular":
                return new RegularUser(username);
            default:
                throw new IllegalArgumentException("Unknown user type: " + type);
        }
    }
}

