/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.models;

public class RegularUser extends User {
    public RegularUser(String username) {
        super(username);
    }

    @Override
    public void performRole() {
        System.out.println("User " + username + " is borrowing books.");
    }
}
