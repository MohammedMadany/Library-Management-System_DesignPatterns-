/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarymanagementsystem;
import library.utils.Logger;

import library.models.Book;
import library.utils.BookFactory;

import library.models.User;
import library.utils.UserFactory;


public class LibraryManagementSystem {
    public static void main(String[] args) {
        // Open the GUI
        java.awt.EventQueue.invokeLater(() -> {
            new LibraryUI().setVisible(true);
        });
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
    Logger logger = Logger.getInstance();
    logger.close();
}));

    }
}
